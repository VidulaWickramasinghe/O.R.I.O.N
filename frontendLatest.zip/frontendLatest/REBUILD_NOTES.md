# O.R.I.O.N. Dashboard Rebuild Notes

## Scope

This rebuild focuses on the frontend dashboard and shared application shell. It deliberately preserves all existing API clients, backend contracts, feature routes, stores, Tauri files and specialist operational panels.

## Dashboard presets

- **Overview:** high-level health, models, alerts and presentation controls
- **Operations:** security, notifications, plugins, permissions, audits, release and stabilization
- **Developer:** workspaces, knowledge, semantic memory, workflows, refactor and diagnostics

## Validation completed in the sandbox

- All TypeScript and TSX source files passed TypeScript syntax transpilation.
- All local `@/` imports resolve to files in the project.
- The uploaded archive was extracted and rebuilt without changing backend API contracts.

A full dependency install and Next.js production build could not be completed in the sandbox because its npm package registry returned HTTP 503. Run `npm install`, `npm run lint` and `npm run build` locally to complete environment-level validation.
