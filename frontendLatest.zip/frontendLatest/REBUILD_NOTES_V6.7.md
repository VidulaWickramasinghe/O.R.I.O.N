# O.R.I.O.N. Frontend v6.7 Rebuild

## Navigation architecture
- Three desktop sidebar states: expanded, compact icon rail, and hidden.
- Explicit collapse, expand, and hide controls.
- Top-bar restore/toggle control remains available when navigation is hidden.
- Ctrl/Cmd+B toggles expanded and compact modes.
- Sidebar mode persists in local storage.
- Navigation groups can be independently folded and their state persists.
- Mobile navigation remains a full-width drawer and is independent of desktop state.
- Active routes, mission counts, workspace identity and command access remain visible in the appropriate mode.

## Analytics and statistics
- New interactive Performance Intelligence workspace.
- 24-hour, 7-day and 30-day reporting windows.
- Execution-throughput and response-latency chart switching.
- Headline statistics for executions, success rate, latency and compute efficiency.
- Mission-outcome donut visualisation.
- Agent-utilisation analysis with task and success indicators.
- Day/time activity heatmap.
- Peak throughput, P95 latency, forecast and workload-concentration insights.
- Existing API-backed operational panels are preserved.

## Version
- Frontend package version updated to 6.7.0.
